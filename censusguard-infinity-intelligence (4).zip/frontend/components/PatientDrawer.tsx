import React, { useState, useEffect } from 'react';
import { X, Activity, AlertTriangle, HeartPulse, FileText, Pill, Stethoscope, History, ShieldAlert, List, TrendingUp, Eye, Network, CheckCircle2 } from 'lucide-react';
import { Patient, AIInsight } from '../types';
import { InsightBubble } from './InsightBubble';
import { generateClinicalInsight } from '../services/gemini';
import { mockInterventionLogs, mockNursingNotes } from '../mockData';

interface PatientDrawerProps {
  patient: Patient | null;
  onClose: () => void;
}

type DrawerTab = 'Overview' | 'MI Guide' | 'Meds' | 'Nursing' | 'Trajectory' | 'Score History' | 'Staff Action Loop' | 'Audit Trail';

export const PatientDrawer: React.FC<PatientDrawerProps> = ({ patient, onClose }) => {
  const [activeTab, setActiveTab] = useState<DrawerTab>('Overview');
  const [insight, setInsight] = useState<AIInsight | null>(null);
  const [isLoadingInsight, setIsLoadingInsight] = useState(false);
  const [insightError, setInsightError] = useState<string | null>(null);

  useEffect(() => {
    if (!patient) {
      setInsight(null);
      setInsightError(null);
      return;
    }

    // Trigger AI Insight if high risk or high velocity
    const shouldTriggerInsight = patient.velocity > 1.5 || patient.flags.includes('Calm-Before-Storm') || patient.riskScore === 'Critical';

    if (shouldTriggerInsight) {
      fetchInsight(patient);
    } else {
      setInsight(null);
      setInsightError(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patient]);

  const fetchInsight = async (p: Patient) => {
    setIsLoadingInsight(true);
    setInsightError(null);
    try {
      const result = await generateClinicalInsight(p, mockInterventionLogs, mockNursingNotes);
      setInsight(result);
    } catch (err: any) {
      setInsightError(err.message);
    } finally {
      setIsLoadingInsight(false);
    }
  };

  const handleFeedback = (isPositive: boolean, reason?: string) => {
    console.log('Feedback submitted:', { patientId: patient?.id, isPositive, reason });
  };

  if (!patient) return null;

  const tabs: { id: DrawerTab; icon: any }[] = [
    { id: 'Overview', icon: Activity },
    { id: 'MI Guide', icon: FileText },
    { id: 'Meds', icon: Pill },
    { id: 'Nursing', icon: Stethoscope },
    { id: 'Trajectory', icon: TrendingUp },
    { id: 'Score History', icon: History },
    { id: 'Staff Action Loop', icon: ShieldAlert },
    { id: 'Audit Trail', icon: List },
  ];

  const isCritical = patient.riskScore === 'Critical';
  const scoreColor = isCritical ? 'text-brand-magenta' : patient.riskScore === 'High' ? 'text-orange-500' : 'text-yellow-500';

  return (
    <div className="fixed inset-y-0 right-0 w-full md:w-[800px] bg-brand-panel border-l border-slate-800 shadow-2xl z-50 flex flex-col animate-slide-in">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 bg-slate-900/50">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
              {patient.name}
              <span className={`text-lg font-bold ${scoreColor}`}>
                {patient.riskScoreValue}
              </span>
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              {patient.unit} • Room {patient.room} • Day {patient.daysInTreatment} • {patient.substance}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={onClose} className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto custom-scrollbar pb-1">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                  isActive 
                    ? 'bg-brand-cyan/10 text-brand-cyan' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.id}
              </button>
            );
          })}
        </div>
      </div>

      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-6 bg-brand-dark">
        
        {activeTab === 'Overview' && (
          <div className="space-y-6">
            
            {/* Infinity Insight Bubble (Executive AI Decision) */}
            {(isLoadingInsight || insight || insightError) && (
              <InsightBubble 
                insight={insight!} 
                isLoading={isLoadingInsight} 
                error={insightError}
                onFeedback={handleFeedback}
              />
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-xs text-slate-500 mb-1 uppercase tracking-wider font-bold">Risk Score</div>
                <div className={`text-3xl font-bold ${scoreColor}`}>{patient.riskScoreValue}</div>
                <div className="text-xs text-slate-400 mt-2">Velocity: {patient.velocity > 0 ? '+' : ''}{patient.velocity}</div>
              </div>
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                <div className="text-xs text-slate-500 mb-1 uppercase tracking-wider font-bold">Counselor</div>
                <div className="text-lg font-bold text-white">{patient.counselor}</div>
              </div>
            </div>

            {/* BHT Observation & Peer Risk */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {patient.lastObservation && (
                <div className={`p-4 rounded-xl border ${patient.lastObservation.isSuspicious ? 'bg-orange-500/10 border-orange-500/30' : 'bg-slate-900 border-slate-800'}`}>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Eye className="w-4 h-4" /> Latest BHT Observation
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Logged By:</span>
                      <span className="text-white font-medium">{patient.lastObservation.staffName}, {patient.lastObservation.staffCredentials}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Time:</span>
                      <span className="text-white">{patient.lastObservation.timestamp}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Location:</span>
                      <span className="text-white">{patient.lastObservation.location}</span>
                    </div>
                    <div className="pt-2 border-t border-slate-800/50">
                      <span className="text-slate-500 block mb-1">Activity:</span>
                      <span className="text-slate-300 italic">"{patient.lastObservation.activity}"</span>
                    </div>
                    {patient.lastObservation.isSuspicious && (
                      <div className="mt-3 p-2 rounded bg-orange-500/20 border border-orange-500/30 text-orange-400 text-xs flex items-start gap-2">
                        <AlertTriangle className="w-4 h-4 shrink-0" />
                        <span><strong>System Warning:</strong> {patient.lastObservation.suspiciousReason}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {patient.peerRisk && patient.peerRisk.length > 0 && (
                <div className="p-4 rounded-xl bg-brand-magenta/10 border border-brand-magenta/30">
                  <h3 className="text-xs font-bold text-brand-magenta uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Network className="w-4 h-4" /> Group Ripple Warning
                  </h3>
                  <p className="text-sm text-brand-magenta/90 leading-relaxed">
                    Patient is currently in proximity to high-risk peer(s): <strong className="text-white">{patient.peerRisk.join(', ')}</strong>.
                  </p>
                  <p className="text-xs text-brand-magenta/70 mt-2">
                    Historical data shows a 40% increase in AMA risk when these specific patients isolate together. Peer separation recommended.
                  </p>
                </div>
              )}
            </div>

            {patient.flags.length > 0 && (
              <div className="p-4 rounded-xl bg-brand-magenta/10 border border-brand-magenta/20">
                <h3 className="text-xs font-bold text-brand-magenta uppercase tracking-wider mb-2 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" /> Active Signals
                </h3>
                <ul className="space-y-2">
                  {patient.flags.map(flag => (
                    <li key={flag} className="text-sm text-brand-magenta/90 flex items-start gap-2">
                      <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-brand-magenta shrink-0"></span>
                      {flag}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
              <h3 className="text-sm font-bold text-white mb-4">Clinical Context</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-slate-500 block mb-1">Pain Score</span>
                  <span className="text-white font-medium">8/10</span>
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">MOUD Status</span>
                  <span className="text-white font-medium">None</span>
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">Psych Comorbidity</span>
                  <span className="text-white font-medium">Yes</span>
                </div>
                <div>
                  <span className="text-slate-500 block mb-1">Admissions</span>
                  <span className="text-white font-medium">3</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'MI Guide' && (
          <div className="space-y-4 animate-fade-in">
            <h3 className="text-lg font-bold text-white mb-2">Motivational Interviewing Guide</h3>
            <p className="text-xs text-slate-400 mb-6">Use this framework to guide the conversation. MI is a collaborative approach.</p>
            
            <div className="space-y-2">
              {[
                'Open with empathy, not urgency.',
                'Explore ambivalence openly.',
                'Elicit change talk.',
                'Affirm patient strength.',
                'Revisit the patient\'s "why".',
                'Collaborate on the next step.',
                'Notify supervisor and document.'
              ].map((step, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-brand-cyan shrink-0"></div>
                  <span className="text-sm text-slate-300">{step}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'Staff Action Loop' && (
          <div className="space-y-6 animate-fade-in">
            <h3 className="text-lg font-bold text-white mb-2">Staff Action Loop</h3>
            <p className="text-xs text-slate-400 mb-6">Accountability layer: who saw the alert, what they did, when they did it, and what happened.</p>
            
            <div className="space-y-4 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-700 before:to-transparent">
              {mockInterventionLogs.map((log, idx) => (
                <div key={log.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-slate-700 bg-slate-900 text-slate-400 shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow">
                    <ShieldAlert className="w-4 h-4" />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-xl border border-slate-800 bg-slate-900 shadow">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <span className="font-bold text-slate-200 text-sm block">{log.authorName}</span>
                        <span className="text-xs text-slate-500">{log.authorRole} • {log.authorCredentials}</span>
                      </div>
                      <time className="text-xs font-medium text-slate-500">
                        {new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </time>
                    </div>
                    <div className="text-slate-300 text-sm mb-2">{log.action}</div>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Signal Quality:</span>
                      <span className="text-xs text-green-500 font-medium">High</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'Audit Trail' && (
          <div className="space-y-6 animate-fade-in">
            <h3 className="text-lg font-bold text-white mb-2">Audit Trail</h3>
            <p className="text-xs text-slate-400 mb-6">Proof that the clinical loop was documented and closed.</p>
            
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-6 mb-6">
              <h4 className="text-sm font-bold text-white mb-6">Current Loop State</h4>
              <div className="flex flex-col md:flex-row justify-between items-center gap-4 relative">
                <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-800 -z-10 -translate-y-1/2"></div>
                
                {['Detect', 'Alert', 'Intervene', 'Document', 'Prove'].map((stage, idx) => {
                  const stageMap: Record<string, number> = { 'detect': 0, 'alert': 1, 'intervene': 2, 'document': 3, 'prove': 4, 'learn': 5 };
                  const currentStageIdx = stageMap[patient.loopStage] || 0;
                  const isPast = idx < currentStageIdx;
                  const isCurrent = idx === currentStageIdx;

                  return (
                    <div key={stage} className="flex flex-col items-center gap-2 bg-slate-900 p-2">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                        isPast ? 'bg-brand-cyan/20 border-brand-cyan text-brand-cyan' :
                        isCurrent ? 'bg-brand-magenta/20 border-brand-magenta text-brand-magenta animate-pulse' :
                        'bg-slate-800 border-slate-700 text-slate-500'
                      }`}>
                        {isPast ? <CheckCircle2 className="w-5 h-5" /> : <span className="font-bold">{idx + 1}</span>}
                      </div>
                      <span className={`text-xs font-bold uppercase tracking-wider ${
                        isPast || isCurrent ? 'text-slate-200' : 'text-slate-500'
                      }`}>{stage}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
              <h4 className="text-sm font-bold text-white mb-4">Action Form</h4>
              <form className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Action Status</label>
                  <select className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-brand-cyan">
                    <option>Intervention Completed</option>
                    <option>Patient Refused</option>
                    <option>Escalated to MD</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Intervention Note</label>
                  <textarea rows={3} className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-brand-cyan resize-none"></textarea>
                </div>
                <button type="button" className="w-full bg-brand-cyan hover:bg-brand-cyan/90 text-brand-dark font-bold py-2.5 rounded-lg transition-colors text-sm">
                  Save Action & Advance Loop
                </button>
              </form>
            </div>
          </div>
        )}

        {['Meds', 'Nursing', 'Trajectory', 'Score History'].includes(activeTab) && (
          <div className="flex flex-col items-center justify-center h-64 text-slate-500 animate-fade-in">
            <Activity className="w-8 h-8 mb-4 text-brand-cyan/50" />
            <p className="text-sm font-medium text-white">{activeTab} Data</p>
            <p className="text-xs mt-1">This section connects to the facility EHR/EMR in production.</p>
          </div>
        )}

      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-slate-800 bg-slate-900 flex gap-4">
        <button className="flex-1 bg-brand-cyan hover:bg-brand-cyan/90 text-brand-dark font-bold py-2.5 rounded-lg transition-colors text-sm">
          Log Intervention
        </button>
        <button className="flex-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-bold py-2.5 rounded-lg transition-colors text-sm">
          View Full Chart
        </button>
      </div>
    </div>
  );
};
