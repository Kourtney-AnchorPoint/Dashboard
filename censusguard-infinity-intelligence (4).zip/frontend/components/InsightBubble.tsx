import React, { useState } from 'react';
import { BrainCircuit, ThumbsUp, ThumbsDown, Send, AlertCircle } from 'lucide-react';
import { AIInsight } from '../types';

interface InsightBubbleProps {
  insight: AIInsight;
  isLoading: boolean;
  error: string | null;
  onFeedback: (isPositive: boolean, reason?: string) => void;
}

export const InsightBubble: React.FC<InsightBubbleProps> = ({ insight, isLoading, error, onFeedback }) => {
  const [feedbackState, setFeedbackState] = useState<'none' | 'positive' | 'negative' | 'submitted'>('none');
  const [reason, setReason] = useState('');

  if (isLoading) {
    return (
      <div className="p-6 rounded-2xl bg-brand-panel border border-brand-magenta/30 shadow-[0_0_15px_rgba(217,70,239,0.15)] animate-pulse">
        <div className="flex items-center gap-3 mb-4">
          <BrainCircuit className="w-6 h-6 text-brand-magenta animate-spin" />
          <h3 className="text-lg font-semibold bg-clip-text text-transparent bg-gradient-to-r from-brand-magenta to-brand-cyan">
            Generating Infinity Insight...
          </h3>
        </div>
        <div className="space-y-3">
          <div className="h-4 bg-slate-800 rounded w-3/4"></div>
          <div className="h-4 bg-slate-800 rounded w-full"></div>
          <div className="h-4 bg-slate-800 rounded w-5/6"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 rounded-2xl bg-red-950/50 border border-red-500/30">
        <div className="flex items-center gap-3 text-red-400">
          <AlertCircle className="w-6 h-6" />
          <p>{error}</p>
        </div>
      </div>
    );
  }

  const handleThumbsDownSubmit = () => {
    onFeedback(false, reason);
    setFeedbackState('submitted');
  };

  const handleThumbsUp = () => {
    onFeedback(true);
    setFeedbackState('submitted');
  };

  return (
    <div className="relative p-6 rounded-2xl bg-brand-panel border border-brand-cyan/30 shadow-[0_0_20px_rgba(6,182,212,0.1)] overflow-hidden">
      {/* Decorative gradient background */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-magenta to-brand-cyan"></div>
      
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-brand-magenta/10 rounded-lg">
            <BrainCircuit className="w-5 h-5 text-brand-magenta" />
          </div>
          <h3 className="text-lg font-bold text-white tracking-wide">
            Staff Action Loop
          </h3>
        </div>
        <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-brand-cyan/10 text-brand-cyan border border-brand-cyan/20">
          MI-Informed
        </span>
      </div>

      <div className="space-y-5">
        <div className="grid grid-cols-[80px_1fr] gap-4 items-start">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1">Who</span>
          <p className="text-slate-200 font-medium">{insight.who}</p>
        </div>
        
        <div className="grid grid-cols-[80px_1fr] gap-4 items-start">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1">What</span>
          <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700/50 text-brand-cyan/90 italic">
            "{insight.what}"
          </div>
        </div>

        <div className="grid grid-cols-[80px_1fr] gap-4 items-start">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1">When</span>
          <p className="text-slate-300">{insight.when}</p>
        </div>

        <div className="grid grid-cols-[80px_1fr] gap-4 items-start">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1">Outcome</span>
          <p className="text-brand-magenta/90 font-medium">{insight.outcome}</p>
        </div>
      </div>

      {/* Feedback Loop */}
      <div className="mt-8 pt-4 border-t border-slate-800 flex flex-col gap-4">
        {feedbackState === 'none' && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-400">Was this insight clinically relevant?</span>
            <div className="flex gap-2">
              <button 
                onClick={handleThumbsUp}
                className="p-2 rounded-lg hover:bg-green-500/20 text-slate-400 hover:text-green-400 transition-colors"
                title="Helpful"
              >
                <ThumbsUp className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setFeedbackState('negative')}
                className="p-2 rounded-lg hover:bg-red-500/20 text-slate-400 hover:text-red-400 transition-colors"
                title="Not Helpful"
              >
                <ThumbsDown className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {feedbackState === 'negative' && (
          <div className="flex gap-2 animate-slide-in">
            <input 
              type="text" 
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Why wasn't this helpful? (Updates Learning Library)"
              className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-brand-magenta"
            />
            <button 
              onClick={handleThumbsDownSubmit}
              disabled={!reason.trim()}
              className="px-3 py-2 bg-brand-magenta text-white rounded-lg disabled:opacity-50 hover:bg-brand-magenta/80 transition-colors flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        )}

        {feedbackState === 'submitted' && (
          <div className="text-sm text-brand-cyan text-center py-2">
            Feedback recorded. The Infinity model has been updated.
          </div>
        )}

        {/* Clinical Disclaimer */}
        <p className="text-[10px] text-slate-500 text-center mt-2 uppercase tracking-wider">
          AI-generated clinical guidance. Staff judgment is the final and absolute authority.
        </p>
      </div>
    </div>
  );
};
