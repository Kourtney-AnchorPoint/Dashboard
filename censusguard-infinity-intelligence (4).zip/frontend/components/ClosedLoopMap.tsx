import React from 'react';
import { Search, Bell, Activity, FileText, CheckCircle, BookOpen, ChevronRight } from 'lucide-react';
import { LoopStage } from '../types';

interface ClosedLoopMapProps {
  activeStageFilter: LoopStage | null;
  onStageClick: (stage: LoopStage) => void;
}

export const ClosedLoopMap: React.FC<ClosedLoopMapProps> = ({ activeStageFilter, onStageClick }) => {
  const steps: { id: LoopStage; label: string; icon: any }[] = [
    { id: 'detect', label: 'Detect', icon: Search },
    { id: 'alert', label: 'Alert', icon: Bell },
    { id: 'intervene', label: 'Intervene', icon: Activity },
    { id: 'document', label: 'Document', icon: FileText },
    { id: 'prove', label: 'Prove', icon: CheckCircle },
    { id: 'learn', label: 'Learn', icon: BookOpen },
  ];

  return (
    <div className="w-full bg-slate-900/50 border-b border-slate-800 py-3 px-8 hidden md:flex items-center justify-center">
      <div className="flex items-center gap-2">
        <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-4">Infinity Loop Filter:</span>
        {steps.map((step, idx) => {
          const Icon = step.icon;
          const isActive = activeStageFilter === step.id;
          
          return (
            <React.Fragment key={step.id}>
              <button 
                onClick={() => onStageClick(step.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all cursor-pointer ${
                  isActive 
                    ? 'bg-brand-cyan/10 border-brand-cyan/50 text-brand-cyan shadow-[0_0_10px_rgba(6,182,212,0.2)]' 
                    : 'bg-slate-900 border-slate-800 text-slate-500 hover:border-slate-600 hover:text-slate-300'
                }`}
                title={`Click to view patients in the ${step.label} stage`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span className="text-xs font-bold uppercase tracking-wider">{step.label}</span>
              </button>
              {idx < steps.length - 1 && (
                <ChevronRight className={`w-4 h-4 ${isActive ? 'text-brand-cyan/50' : 'text-slate-700'}`} />
              )}
            </React.Fragment>
          );
        })}
        
        {activeStageFilter && (
          <button 
            onClick={() => onStageClick(activeStageFilter)} // Clicking active again clears it
            className="ml-4 text-xs text-slate-500 hover:text-brand-magenta underline transition-colors"
          >
            Clear Filter
          </button>
        )}
      </div>
    </div>
  );
};
