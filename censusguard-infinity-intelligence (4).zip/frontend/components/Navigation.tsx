import React from 'react';
import { ShieldAlert, Users, Map, TrendingUp, BarChart2, FileText, Stethoscope, Settings, Shield, Network, MessageSquare, BookOpen } from 'lucide-react';

export type TabType = 'monitor' | 'floorplan' | 'groupflow' | 'narrative' | 'command' | 'outcomes' | 'moud' | 'learn' | 'staff' | 'psych' | 'settings';

interface NavigationProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: 'monitor', icon: Users, label: 'Patient Monitor' },
    { id: 'floorplan', icon: Map, label: 'Census Floor' },
    { id: 'groupflow', icon: Network, label: 'Group Flow' },
    { id: 'narrative', icon: MessageSquare, label: 'Narrative Notes' },
    { id: 'command', icon: ShieldAlert, label: 'Alerts / Command' },
    { id: 'outcomes', icon: TrendingUp, label: 'Outcomes' },
    { id: 'moud', icon: BarChart2, label: 'MOUD Analysis' },
    { id: 'learn', icon: BookOpen, label: 'Learn' },
    { id: 'staff', icon: FileText, label: 'Staff Docs' },
    { id: 'psych', icon: Stethoscope, label: 'Psych / Medical' },
  ] as const;

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-brand-panel border-r border-slate-800 h-screen sticky top-0">
        <div className="p-6 flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-brand-magenta to-brand-cyan rounded-xl shadow-lg">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white tracking-tight leading-tight">CensusGuard</h1>
            <p className="text-[10px] text-brand-cyan font-medium tracking-widest uppercase">Infinity System</p>
          </div>
        </div>
        
        <div className="px-6 pb-4">
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search patient..." 
              className="w-full bg-slate-900 border border-slate-700 rounded-md pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-brand-cyan transition-colors"
            />
            <svg className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
          </div>
        </div>

        <nav className="flex-1 px-3 space-y-1 overflow-y-auto custom-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 text-sm ${
                  isActive 
                    ? 'bg-brand-cyan/10 text-brand-cyan border border-brand-cyan/20 shadow-[0_0_15px_rgba(6,182,212,0.1)]' 
                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200 border border-transparent'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-brand-cyan' : 'text-slate-500'}`} />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 mt-auto border-t border-slate-800">
          <button 
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all text-sm ${
              activeTab === 'settings' ? 'bg-brand-cyan/10 text-brand-cyan' : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span className="font-medium">Settings</span>
          </button>
        </div>
      </aside>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-brand-panel border-t border-slate-800 pb-safe z-50">
        <div className="flex justify-around items-center h-16 px-2 overflow-x-auto custom-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center min-w-[64px] h-full space-y-1 ${
                  isActive ? 'text-brand-cyan' : 'text-slate-500'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'animate-pulse-slow' : ''}`} />
                <span className="text-[10px] font-medium whitespace-nowrap">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
