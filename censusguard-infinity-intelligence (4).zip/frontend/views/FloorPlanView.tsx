import React, { useState } from 'react';
import { Map } from 'lucide-react';
import { Room, Patient } from '../types';

interface FloorPlanViewProps {
  rooms: Room[];
  patients: Patient[];
  onSelectPatient: (patient: Patient) => void;
}

export const FloorPlanView: React.FC<FloorPlanViewProps> = ({ rooms, patients, onSelectPatient }) => {
  const [selectedUnit, setSelectedUnit] = useState<string>('All');
  
  const getPatientDetails = (patientId: string) => {
    return patients.find(p => p.id === patientId);
  };

  const allUnits = ['Detox', 'Residential', 'PHP', 'IOP'];
  const displayUnits = selectedUnit === 'All' ? allUnits : [selectedUnit];

  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Map className="w-6 h-6 text-brand-cyan" />
            Census Floor
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Risk visualization by unit, room, and proximity.
          </p>
        </div>

        {/* Unit Filter Pills */}
        <div className="flex flex-wrap items-center gap-2">
          <button 
            onClick={() => setSelectedUnit('All')}
            className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-colors ${
              selectedUnit === 'All' ? 'bg-brand-cyan text-brand-dark' : 'bg-slate-900 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            All Units
          </button>
          {allUnits.map(unit => (
            <button 
              key={unit}
              onClick={() => setSelectedUnit(unit)}
              className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-colors ${
                selectedUnit === unit ? 'bg-brand-cyan text-brand-dark' : 'bg-slate-900 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              {unit}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {displayUnits.map(unit => {
          const unitRooms = rooms.filter(r => r.unit === unit);
          const activeCount = unitRooms.reduce((acc, r) => acc + r.patients.length, 0);

          return (
            <div key={unit} className="bg-slate-900 border border-slate-800 rounded-xl p-6">
              <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
                <h3 className="text-lg font-bold text-white">{unit}</h3>
                <span className="text-xs font-medium px-2 py-1 bg-slate-800 rounded-md text-slate-300">{activeCount} Active</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {unitRooms.map(room => (
                  <div key={room.id} className="bg-slate-950 border border-slate-800 rounded-lg p-4">
                    <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Room {room.number}</div>
                    <div className="space-y-2">
                      {room.patients.map(pid => {
                        const p = getPatientDetails(pid);
                        if (!p) return null;
                        
                        const isCritical = p.riskScore === 'Critical';
                        const isHigh = p.riskScore === 'High';
                        const scoreColor = isCritical ? 'text-brand-magenta' : isHigh ? 'text-orange-500' : 'text-brand-cyan';

                        return (
                          <div 
                            key={pid} 
                            onClick={() => onSelectPatient(p)}
                            className="flex justify-between items-center p-2 rounded bg-slate-900 border border-slate-800 hover:border-brand-cyan/50 cursor-pointer transition-colors"
                          >
                            <span className="text-sm font-bold text-slate-200">{p.name}</span>
                            <span className={`text-sm font-bold ${scoreColor}`}>{p.riskScoreValue}</span>
                          </div>
                        );
                      })}
                      {Array.from({ length: room.capacity - room.patients.length }).map((_, i) => (
                        <div key={`empty-${i}`} className="flex justify-between items-center p-2 rounded border border-dashed border-slate-700 opacity-50">
                          <span className="text-sm font-medium text-slate-500">Empty</span>
                          <span className="text-sm font-bold text-slate-600">-</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
                {unitRooms.length === 0 && (
                  <div className="col-span-2 text-center py-6 text-sm text-slate-600">
                    No rooms configured for this unit.
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
