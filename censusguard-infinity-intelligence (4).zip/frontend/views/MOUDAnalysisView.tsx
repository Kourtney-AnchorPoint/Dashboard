import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { BarChart2 } from 'lucide-react';
import { MOUDData } from '../types';

interface MOUDAnalysisViewProps {
  data: MOUDData[];
}

export const MOUDAnalysisView: React.FC<MOUDAnalysisViewProps> = ({ data }) => {
  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <BarChart2 className="w-6 h-6 text-brand-cyan" />
          MOUD Systems Analysis
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Evaluating AMA risk factors across levels of care.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8">
        <h3 className="text-xl font-bold text-white mb-3 leading-relaxed">
          MOUD patients in long-term residential leave AMA at <span className="text-brand-magenta">43.7%</span> - nearly 8 points higher than non-MOUD patients in the same setting.
        </h3>
        <p className="text-base text-slate-400 mb-10">
          The gap is not clinical failure, it is a systems visibility failure. CensusGuard catches the signal before it becomes a walkout.
        </p>

        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 20, right: 30, left: -20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
              <XAxis 
                dataKey="setting" 
                stroke="#64748b" 
                tick={{ fill: '#94a3b8', fontSize: 14 }} 
                axisLine={false}
                tickLine={false}
              />
              <YAxis 
                stroke="#64748b" 
                tick={{ fill: '#94a3b8', fontSize: 14 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(value) => `${value}%`}
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#fff', borderRadius: '8px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Legend wrapperStyle={{ fontSize: '14px', paddingTop: '20px' }} />
              <Bar dataKey="moudRate" name="MOUD AMA Rate" fill="#d946ef" radius={[4, 4, 0, 0]} />
              <Bar dataKey="nonMoudRate" name="Non-MOUD AMA Rate" fill="#06b6d4" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
