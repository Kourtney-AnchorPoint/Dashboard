import React from 'react';
import { Library, TrendingUp, BookOpen, CheckCircle, XCircle, MinusCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { AnalyticsData, InterventionLog } from '../types';

interface LearningLibraryViewProps {
  analytics: AnalyticsData[];
  logs: InterventionLog[];
}

export const LearningLibraryView: React.FC<LearningLibraryViewProps> = ({ analytics, logs }) => {
  
  // Custom Tooltip for Recharts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg shadow-xl">
          <p className="text-white font-bold mb-1">{label} Risk</p>
          <p className="text-brand-cyan text-sm">
            Success Rate: <span className="font-bold">{payload[0].value}%</span>
          </p>
          <p className="text-slate-400 text-xs mt-1">
            Total Interventions: {payload[0].payload.totalInterventions}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Library className="w-6 h-6 text-brand-cyan" />
          Intelligence Library
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Success analytics and the Staff Action Stream audit trail.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Analytics */}
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-brand-magenta" />
                Intervention Efficacy by Risk Tier
              </h3>
            </div>
            
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics} margin={{ top: 20, right: 30, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis 
                    dataKey="riskTier" 
                    stroke="#64748b" 
                    tick={{ fill: '#94a3b8', fontSize: 12 }} 
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis 
                    stroke="#64748b" 
                    tick={{ fill: '#94a3b8', fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(value) => `${value}%`}
                  />
                  <Tooltip content={<CustomTooltip />} cursor={{ fill: '#0f172a' }} />
                  <Bar dataKey="successRate" radius={[4, 4, 0, 0]}>
                    {analytics.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={
                        entry.riskTier === 'Critical' ? '#ef4444' : // red-500
                        entry.riskTier === 'High' ? '#f97316' :     // orange-500
                        entry.riskTier === 'Moderate' ? '#eab308' : // yellow-500
                        '#22c55e'                                   // green-500
                      } />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">
              Systemic Barrier Insights
            </h3>
            <p className="text-sm text-slate-300 leading-relaxed">
              Analysis indicates that <span className="text-brand-magenta font-bold">72%</span> of negative outcomes in the High Risk tier occur during shift changes. Implementing the "Calm-Before-Storm" protocol 30 minutes prior to shift change is recommended.
            </p>
          </div>
        </div>

        {/* Right Column: Staff Action Stream */}
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 flex flex-col h-[600px]">
          <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2 shrink-0">
            <BookOpen className="w-5 h-5 text-brand-cyan" />
            Staff Action Stream
          </h3>
          
          <div className="flex-1 overflow-y-auto pr-2 space-y-4 custom-scrollbar">
            {logs.map(log => (
              <div key={log.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-200 text-sm">{log.authorRole}</span>
                    <span className="text-xs text-slate-500">
                      {new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    {log.outcome === 'positive' && <CheckCircle className="w-4 h-4 text-green-500" />}
                    {log.outcome === 'negative' && <XCircle className="w-4 h-4 text-red-500" />}
                    {log.outcome === 'neutral' && <MinusCircle className="w-4 h-4 text-slate-500" />}
                  </div>
                </div>
                
                <p className="text-sm text-slate-300 mb-3">{log.action}</p>
                
                {log.lessonLearned && (
                  <div className="p-3 rounded-lg bg-brand-magenta/10 border border-brand-magenta/20">
                    <span className="text-xs font-bold text-brand-magenta uppercase tracking-wider block mb-1">
                      Lesson Learned
                    </span>
                    <p className="text-sm text-brand-magenta/90 italic">
                      "{log.lessonLearned}"
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
