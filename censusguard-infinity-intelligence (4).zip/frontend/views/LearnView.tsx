import React from 'react';
import { BookOpen, Save } from 'lucide-react';

export const LearnView: React.FC = () => {
  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <BookOpen className="w-6 h-6 text-brand-cyan" />
          Intervention Learning
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Log interventions and teach the system what worked to improve future risk scoring.
        </p>
      </div>

      <div className="max-w-4xl bg-slate-900 border border-slate-800 rounded-xl p-8">
        <form className="space-y-8">
          
          {/* Section 1: Context */}
          <div>
            <h3 className="text-sm font-bold text-brand-cyan uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">1. Clinical Context</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Patient Name</label>
                <select className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan">
                  <option>Select Patient...</option>
                  <option>David L.</option>
                  <option>Sarah J.</option>
                  <option>Chloe M.</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Risk Tier at Intervention</label>
                <select className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan">
                  <option>Critical</option>
                  <option>High</option>
                  <option>Moderate</option>
                  <option>Low</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Staff Name & Credentials</label>
                <input 
                  type="text" 
                  placeholder="e.g., Jane Roe, LCSW"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Action */}
          <div>
            <h3 className="text-sm font-bold text-brand-cyan uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">2. The Intervention</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Intervention Type</label>
                <select className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan">
                  <option>MI 1:1 Session</option>
                  <option>MAT Consult</option>
                  <option>Family Outreach</option>
                  <option>Care Plan Adjustment</option>
                  <option>Peer Separation</option>
                  <option>Psych Referral</option>
                  <option>Pain Management</option>
                  <option>Housing Support</option>
                  <option>Vocational Support</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Tags (Comma separated)</label>
                <input 
                  type="text" 
                  placeholder="e.g., de-escalation, boundary setting"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Intervention Notes</label>
              <textarea 
                rows={3}
                placeholder="What was discussed or done? (Who, what, when, where, why)"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan resize-none"
              ></textarea>
            </div>
          </div>

          {/* Section 3: Outcome */}
          <div>
            <h3 className="text-sm font-bold text-brand-cyan uppercase tracking-wider mb-4 border-b border-slate-800 pb-2">3. The Outcome</h3>
            
            <div className="mb-6">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">Outcome Status</label>
              <div className="flex gap-6">
                <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                  <input type="radio" name="outcome" className="accent-brand-cyan w-4 h-4" defaultChecked />
                  Successful
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                  <input type="radio" name="outcome" className="accent-brand-cyan w-4 h-4" />
                  Neutral
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                  <input type="radio" name="outcome" className="accent-brand-cyan w-4 h-4" />
                  Unsuccessful
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Score Before</label>
                <input type="number" placeholder="e.g., 85" className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Score After</label>
                <input type="number" placeholder="e.g., 65" className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">What Worked</label>
                <textarea 
                  rows={2}
                  placeholder="Specific tactics that succeeded..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan resize-none"
                ></textarea>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">What Didn't Work</label>
                <textarea 
                  rows={2}
                  placeholder="Specific tactics that failed or escalated..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan resize-none"
                ></textarea>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Outcome Notes</label>
              <textarea 
                rows={2}
                placeholder="General observations about the patient's response..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-cyan resize-none"
              ></textarea>
            </div>
          </div>

          {/* Section 4: Machine Learning Feedback */}
          <div className="p-6 rounded-xl bg-brand-magenta/10 border border-brand-magenta/30">
            <label className="block text-xs font-bold text-brand-magenta uppercase tracking-wider mb-2 flex items-center gap-2">
              <BookOpen className="w-4 h-4" /> Lessons Learned (For AI Model)
            </label>
            <p className="text-xs text-brand-magenta/80 mb-3">This text is vectorized and fed directly into the Infinity Intelligence model to improve future recommendations for similar patients.</p>
            <textarea 
              rows={3}
              placeholder="Summarize the key takeaway for future interventions..."
              className="w-full bg-slate-950 border border-brand-magenta/50 rounded-lg px-4 py-3 text-sm text-white focus:outline-none focus:border-brand-magenta resize-none"
            ></textarea>
          </div>

          <button type="button" className="w-full flex items-center justify-center gap-2 bg-brand-cyan hover:bg-brand-cyan/90 text-brand-dark font-bold py-4 rounded-xl transition-colors text-sm mt-6 shadow-[0_0_20px_rgba(6,182,212,0.2)]">
            <Save className="w-5 h-5" />
            Save & Feed Model
          </button>
        </form>
      </div>
    </div>
  );
};
