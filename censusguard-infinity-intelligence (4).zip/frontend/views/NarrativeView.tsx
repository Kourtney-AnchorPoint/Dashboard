import React from 'react';
import { MessageSquare, AlertTriangle, CheckCircle, Activity } from 'lucide-react';
import { NarrativeNote } from '../types';

interface NarrativeViewProps {
  notes: NarrativeNote[];
}

export const NarrativeView: React.FC<NarrativeViewProps> = ({ notes }) => {
  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <MessageSquare className="w-6 h-6 text-brand-cyan" />
          Narrative / Group Notes
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Track group observations and clinical narratives that affect risk.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="space-y-4">
          {notes.map(note => (
            <div key={note.id} className="p-5 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-3">
                  <div className={`px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider border ${
                    note.type === 'Conflict' ? 'bg-brand-magenta/10 text-brand-magenta border-brand-magenta/20' :
                    note.type === 'Positive' ? 'bg-brand-cyan/10 text-brand-cyan border-brand-cyan/20' :
                    'bg-slate-800 text-slate-300 border-slate-700'
                  }`}>
                    {note.type}
                  </div>
                  <span className="text-sm font-bold text-slate-200">{note.unit}</span>
                </div>
                <span className="text-xs text-slate-500">
                  {new Date(note.timestamp).toLocaleString()}
                </span>
              </div>
              
              <p className="text-sm text-slate-300 mb-4 leading-relaxed">{note.text}</p>
              
              <div className="flex items-center justify-between pt-3 border-t border-slate-800/50">
                <div className="text-xs text-slate-400">
                  Logged by <span className="font-medium text-slate-300">{note.authorName}</span>
                </div>
                {note.cohesionScore && (
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-slate-500">Cohesion Score:</span>
                    <span className={`font-bold ${note.cohesionScore > 80 ? 'text-brand-cyan' : 'text-orange-500'}`}>
                      {note.cohesionScore}
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
