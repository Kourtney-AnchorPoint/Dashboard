import React, { useState } from 'react';
import { Users, Search, Activity, HeartPulse, AlertTriangle, Filter, Eye, Network } from 'lucide-react';
import { Patient, LoopStage } from '../types';

interface MonitorViewProps {
  patients: Patient[];
  onSelectPatient: (patient: Patient) => void;
  loopFilter: LoopStage | null;
}

export const MonitorView: React.FC<MonitorViewProps> = ({ patients, onSelectPatient, loopFilter }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState<string>('All Tiers');

  const filteredPatients = patients.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.room.includes(searchQuery);
    const matchesRisk = riskFilter === 'All Tiers' || p.riskScore === riskFilter;
    const matchesLoop = loopFilter === null || p.loopStage === loopFilter;
    return matchesSearch && matchesRisk && matchesLoop;
  });

  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-brand-cyan" />
            Patient Monitor Grid
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {loopFilter 
              ? <span className="text-brand-cyan font-medium">Filtered by Infinity Loop Stage: {loopFilter.toUpperCase()}</span>
              : 'Triage table with velocity highlighting and risk sorting.'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative flex-1 md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search patients, rooms..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-brand-cyan transition-colors"
            />
          </div>
          <div className="relative">
            <select 
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              className="appearance-none bg-slate-900 border border-slate-700 rounded-xl pl-4 pr-10 py-2 text-sm text-white focus:outline-none focus:border-brand-cyan transition-colors cursor-pointer"
            >
              <option value="All Tiers">All Tiers</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Moderate">Moderate</option>
              <option value="Low">Low</option>
            </select>
            <Filter className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredPatients.map(patient => {
          const isHighRisk = patient.riskScore === 'Critical' || patient.riskScore === 'High';
          const hasStormFlag = patient.flags.includes('Calm-Before-Storm');
          const hasSuspiciousLog = patient.lastObservation?.isSuspicious;
          const hasPeerRisk = patient.peerRisk && patient.peerRisk.length > 0;
          
          return (
            <div 
              key={patient.id}
              onClick={() => onSelectPatient(patient)}
              className={`relative p-6 rounded-2xl cursor-pointer transition-all duration-300 hover:-translate-y-1 group flex flex-col
                ${isHighRisk 
                  ? 'bg-slate-900 border border-red-500/30 hover:border-red-500/60 hover:shadow-[0_0_20px_rgba(239,68,68,0.15)]' 
                  : 'bg-slate-900 border border-slate-800 hover:border-brand-cyan/50 hover:shadow-[0_0_20px_rgba(6,182,212,0.1)]'
                }
              `}
            >
              {/* Highlight for AI Trigger condition */}
              {(patient.velocity > 1.5 || hasStormFlag) && (
                <div className="absolute -top-2 -right-2 w-4 h-4 rounded-full bg-brand-magenta animate-ping"></div>
              )}
              {(patient.velocity > 1.5 || hasStormFlag) && (
                <div className="absolute -top-2 -right-2 w-4 h-4 rounded-full bg-brand-magenta border-2 border-brand-dark"></div>
              )}

              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-brand-cyan transition-colors">
                    {patient.name}
                  </h3>
                  <p className="text-sm text-slate-400">{patient.unit} • Room {patient.room}</p>
                </div>
                <div className={`px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider flex items-center gap-2
                  ${patient.riskScore === 'Critical' ? 'bg-red-500/20 text-red-400' : 
                    patient.riskScore === 'High' ? 'bg-orange-500/20 text-orange-400' : 
                    patient.riskScore === 'Moderate' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-green-500/20 text-green-400'}
                `}>
                  <span>{patient.riskScore}</span>
                  <span className="text-sm">{patient.riskScoreValue}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-slate-950/50 rounded-lg p-3 border border-slate-800/50">
                  <div className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                    <Activity className="w-3 h-3" /> Velocity
                  </div>
                  <div className={`text-lg font-semibold ${patient.velocity > 1.5 ? 'text-brand-magenta' : 'text-slate-200'}`}>
                    {patient.velocity > 0 ? '+' : ''}{patient.velocity.toFixed(1)}
                  </div>
                </div>
                <div className="bg-slate-950/50 rounded-lg p-3 border border-slate-800/50">
                  <div className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                    <HeartPulse className="w-3 h-3" /> HR
                  </div>
                  <div className="text-lg font-semibold text-slate-200">
                    {patient.vitals.hr} <span className="text-xs font-normal text-slate-500">bpm</span>
                  </div>
                </div>
              </div>

              {/* BHT Observation & Peer Risk Section */}
              <div className="flex-1 flex flex-col justify-end space-y-2 mb-4">
                {patient.lastObservation && (
                  <div className={`p-2.5 rounded-lg border text-xs ${hasSuspiciousLog ? 'bg-orange-500/10 border-orange-500/30' : 'bg-slate-950 border-slate-800'}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-slate-400 flex items-center gap-1">
                        <Eye className="w-3 h-3" /> Last Obs ({patient.lastObservation.timestamp})
                      </span>
                      <span className="text-slate-500">{patient.lastObservation.staffName}, {patient.lastObservation.staffCredentials}</span>
                    </div>
                    <div className="text-slate-300">
                      <span className="text-slate-500">Loc:</span> {patient.lastObservation.location} • <span className="text-slate-500">Act:</span> {patient.lastObservation.activity}
                    </div>
                    {hasSuspiciousLog && (
                      <div className="mt-1 text-orange-400 font-medium flex items-start gap-1">
                        <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                        <span>Low-signal entry detected.</span>
                      </div>
                    )}
                  </div>
                )}

                {hasPeerRisk && (
                  <div className="p-2.5 rounded-lg bg-brand-magenta/10 border border-brand-magenta/30 text-xs">
                    <div className="font-bold text-brand-magenta flex items-center gap-1 mb-1">
                      <Network className="w-3 h-3" /> Group Ripple Warning
                    </div>
                    <div className="text-brand-magenta/80">
                      In proximity to high-risk peer: <span className="font-bold">{patient.peerRisk?.join(', ')}</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-800/50">
                <div className="text-xs text-slate-400">
                  <span className="font-medium text-slate-300">{patient.counselor}</span> • Day {patient.daysInTreatment}
                </div>
                {patient.flags.length > 0 && (
                  <div className="flex items-center gap-1.5 text-xs text-brand-magenta bg-brand-magenta/10 px-2 py-1 rounded-md border border-brand-magenta/20">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span className="truncate max-w-[100px]">{patient.flags[0]}</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
        
        {filteredPatients.length === 0 && (
          <div className="col-span-full text-center py-12 text-slate-500">
            No patients found matching the current filters.
          </div>
        )}
      </div>
    </div>
  );
};
