import React, { useState } from 'react';
import { Network, Users } from 'lucide-react';
import { Patient } from '../types';

interface GroupFlowViewProps {
  patients: Patient[];
  onSelectPatient: (patient: Patient) => void;
}

export const GroupFlowView: React.FC<GroupFlowViewProps> = ({ patients, onSelectPatient }) => {
  const [selectedUnit, setSelectedUnit] = useState<string>('All');
  
  const allStages = ['Detox', 'Residential', 'PHP', 'IOP'];
  const displayStages = selectedUnit === 'All' ? allStages : [selectedUnit];

  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Network className="w-6 h-6 text-brand-cyan" />
            Group Flow
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Cohort-level risk and level-of-care movement.
          </p>
        </div>

        {/* Unit Filter Pills */}
        <div className="flex flex-wrap items-center gap-2">
          <button 
            onClick={() => setSelectedUnit('All')}
            className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-colors ${
              selectedUnit === 'All' ? 'bg-brand-cyan text-brand-dark' : 'bg-slate-900 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            All Flow
          </button>
          {allStages.map(unit => (
            <button 
              key={unit}
              onClick={() => setSelectedUnit(unit)}
              className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider transition-colors ${
                selectedUnit === unit ? 'bg-brand-cyan text-brand-dark' : 'bg-slate-900 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              {unit}
            </button>
          ))}
        </div>
      </div>

      <div className={`grid grid-cols-1 gap-6 ${selectedUnit === 'All' ? 'md:grid-cols-2 lg:grid-cols-4' : 'max-w-md'}`}>
        {displayStages.map((stage, idx) => {
          const stagePatients = patients.filter(p => p.unit === stage);
          const avgRisk = stagePatients.length > 0 
            ? Math.round(stagePatients.reduce((acc, p) => acc + p.riskScoreValue, 0) / stagePatients.length)
            : 0;

          return (
            <div key={stage} className="bg-slate-900 border border-slate-800 rounded-xl p-6 relative">
              {selectedUnit === 'All' && idx < allStages.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-0.5 bg-slate-700 z-0"></div>
              )}
              <h3 className="text-lg font-bold text-white mb-4">{stage}</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Cohort Size</span>
                  <span className="text-lg font-bold text-white flex items-center gap-1">
                    <Users className="w-4 h-4 text-brand-cyan" /> {stagePatients.length}
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Avg Risk</span>
                  <span className={`text-lg font-bold ${avgRisk > 75 ? 'text-brand-magenta' : avgRisk > 50 ? 'text-orange-500' : 'text-brand-cyan'}`}>
                    {avgRisk || '-'}
                  </span>
                </div>

                <div className="pt-4 border-t border-slate-800">
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">High Risk Patients</div>
                  <div className="space-y-2">
                    {stagePatients.filter(p => p.riskScore === 'Critical' || p.riskScore === 'High').map(p => (
                      <div 
                        key={p.id} 
                        onClick={() => onSelectPatient(p)}
                        className="text-sm text-slate-300 flex justify-between items-center p-2 rounded bg-slate-950 border border-slate-800 hover:border-brand-cyan/50 cursor-pointer transition-colors"
                      >
                        <span className="font-medium">{p.name}</span>
                        <span className={`font-bold ${p.riskScore === 'Critical' ? 'text-brand-magenta' : 'text-orange-500'}`}>
                          {p.riskScoreValue}
                        </span>
                      </div>
                    ))}
                    {stagePatients.filter(p => p.riskScore === 'Critical' || p.riskScore === 'High').length === 0 && (
                      <div className="text-sm text-slate-600">None</div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
