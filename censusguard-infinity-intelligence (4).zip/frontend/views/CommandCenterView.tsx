import React from 'react';
import { ShieldAlert, Users, Activity, Zap, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Alert, Patient } from '../types';

interface CommandCenterViewProps {
  alerts: Alert[];
  patients: Patient[];
}

export const CommandCenterView: React.FC<CommandCenterViewProps> = ({ alerts, patients }) => {
  
  const velocityWatchlist = [...patients].sort((a, b) => b.velocity - a.velocity).slice(0, 5);

  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <ShieldAlert className="w-6 h-6 text-brand-cyan" />
          Clinical Command Center
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Real-time intelligence and unit overview.
        </p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-bold">Unit Capacity</span>
            <Users className="w-4 h-4 text-brand-cyan" />
          </div>
          <div className="text-2xl font-bold text-white">85%</div>
          <div className="text-[10px] text-slate-500 mt-1">42/50 Beds Filled</div>
        </div>
        
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-bold">Critical Risk</span>
            <ShieldAlert className="w-4 h-4 text-brand-magenta" />
          </div>
          <div className="text-2xl font-bold text-white">3</div>
          <div className="text-[10px] text-brand-magenta mt-1">+1 since last shift</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-bold">Avg Velocity</span>
            <Zap className="w-4 h-4 text-yellow-500" />
          </div>
          <div className="text-2xl font-bold text-white">14m</div>
          <div className="text-[10px] text-green-500 mt-1">-2m improvement</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-bold">BHT Signal</span>
            <Activity className="w-4 h-4 text-green-500" />
          </div>
          <div className="text-2xl font-bold text-white">92%</div>
          <div className="text-[10px] text-slate-500 mt-1">High reliability</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Alerts & Workflow */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Intelligence Alerts */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-brand-magenta" />
              Intelligence Alerts
            </h3>
            <div className="space-y-3">
              {alerts.map(alert => (
                <div key={alert.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex gap-4">
                  <div className="mt-1">
                    {alert.type === 'critical' ? (
                      <div className="w-8 h-8 rounded-lg bg-brand-magenta/20 flex items-center justify-center">
                        <Zap className="w-4 h-4 text-brand-magenta" />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-lg bg-brand-cyan/20 flex items-center justify-center">
                        <ShieldAlert className="w-4 h-4 text-brand-cyan" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-bold text-sm text-white">{alert.patientName}</span>
                      <span className="text-[10px] text-slate-500">{alert.timestamp}</span>
                    </div>
                    <p className="text-sm text-slate-300 mb-2">{alert.message}</p>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-slate-500">Recommended:</span>
                      <span className="text-brand-cyan font-medium">{alert.recommendedAction}</span>
                      <span className="text-slate-600 mx-1">•</span>
                      <span className="text-slate-500">Assigned:</span>
                      <span className="text-white font-medium">{alert.assignedTo}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Staff Action Loop Workflow Visualization */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <h3 className="text-lg font-bold text-white mb-6">Staff Action Loop™ Status</h3>
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 relative">
              {/* Connecting Line */}
              <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-800 -z-10 -translate-y-1/2"></div>
              
              {['Detect', 'Alert', 'Intervene', 'Document', 'Prove'].map((stage, idx) => (
                <div key={stage} className="flex flex-col items-center gap-2 bg-slate-900 p-2">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${
                    idx < 3 ? 'bg-brand-magenta/20 border-brand-magenta text-brand-magenta' :
                    idx === 3 ? 'bg-brand-cyan/20 border-brand-cyan text-brand-cyan animate-pulse' :
                    'bg-slate-800 border-slate-700 text-slate-500'
                  }`}>
                    {idx < 3 ? <CheckCircle2 className="w-5 h-5" /> : <span className="font-bold">{idx + 1}</span>}
                  </div>
                  <span className={`text-xs font-bold uppercase tracking-wider ${
                    idx <= 3 ? 'text-slate-200' : 'text-slate-500'
                  }`}>{stage}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Velocity Watchlist */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h3 className="text-lg font-bold text-white mb-4">Velocity Watchlist</h3>
          <div className="space-y-2">
            {velocityWatchlist.map(patient => (
              <div key={patient.id} className="flex items-center justify-between p-3 rounded-lg bg-slate-950 border border-slate-800 hover:border-brand-cyan/50 transition-colors">
                <div>
                  <div className="font-bold text-sm text-slate-200">{patient.name}</div>
                  <div className="text-[10px] text-slate-500">{patient.unit}</div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className={`text-sm font-bold ${patient.velocity > 1.5 ? 'text-brand-magenta' : 'text-orange-500'}`}>
                      +{patient.velocity.toFixed(1)}
                    </div>
                  </div>
                  <div className="w-8 h-4 flex items-end gap-0.5">
                    <div className="w-1.5 h-2 bg-slate-700 rounded-t-sm"></div>
                    <div className="w-1.5 h-3 bg-slate-600 rounded-t-sm"></div>
                    <div className={`w-1.5 h-4 rounded-t-sm ${patient.velocity > 1.5 ? 'bg-brand-magenta' : 'bg-orange-500'}`}></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
