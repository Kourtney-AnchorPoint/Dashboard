import React, { useState } from 'react';
import { Settings, Shield, Users, Database, AlertOctagon, Lock, Key } from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Settings className="w-6 h-6 text-brand-cyan" />
          Settings & Account Management
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Manage organization, roles, and security configurations.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <Shield className="w-6 h-6 text-brand-cyan mb-4" />
          <h3 className="text-lg font-bold text-white mb-2">Account Settings</h3>
          <ul className="space-y-2 text-sm text-slate-400">
            <li className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span>Profile Information</span>
              <button className="text-brand-cyan hover:underline">Edit</button>
            </li>
            <li className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span>Notification Preferences</span>
              <button className="text-brand-cyan hover:underline">Edit</button>
            </li>
            <li className="flex items-center justify-between py-1">
              <span>Two-Factor Auth (2FA)</span>
              <span className="text-green-500 font-medium">Enabled</span>
            </li>
          </ul>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <Database className="w-6 h-6 text-brand-cyan mb-4" />
          <h3 className="text-lg font-bold text-white mb-2">Organization / Facility</h3>
          <ul className="space-y-2 text-sm text-slate-400">
            <li className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span>Facility Name</span>
              <span className="text-white">Recovery Center Alpha</span>
            </li>
            <li className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span>EHR Integration</span>
              <span className="text-green-500 font-medium">Connected (Kipu)</span>
            </li>
            <li className="flex items-center justify-between py-1">
              <span>Data Retention Policy</span>
              <button className="text-brand-cyan hover:underline">View</button>
            </li>
          </ul>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <Users className="w-6 h-6 text-brand-cyan mb-4" />
          <h3 className="text-lg font-bold text-white mb-2">User Roles & Access</h3>
          <ul className="space-y-2 text-sm text-slate-400">
            <li className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span>Role-Based Access Control</span>
              <button className="text-brand-cyan hover:underline">Manage</button>
            </li>
            <li className="flex items-center justify-between py-1 border-b border-slate-800/50">
              <span>User Provisioning</span>
              <button className="text-brand-cyan hover:underline">Manage</button>
            </li>
            <li className="flex items-center justify-between py-1">
              <span>SSO Configuration</span>
              <span className="text-slate-500">Not Configured</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Security & Audit Section */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-8">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Key className="w-5 h-5 text-brand-cyan" />
          Security & Audit Logs
        </h3>
        <p className="text-sm text-slate-400 mb-4">
          Production environments require strict audit logging and PHI-safe handling procedures.
        </p>
        <div className="flex gap-4">
          <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-bold transition-colors">
            Download Audit Log (CSV)
          </button>
          <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-bold transition-colors">
            View Access History
          </button>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-red-950/20 border border-red-900/50 rounded-xl p-6">
        <h3 className="text-lg font-bold text-red-500 mb-2 flex items-center gap-2">
          <AlertOctagon className="w-5 h-5" />
          Danger Zone
        </h3>
        <p className="text-sm text-slate-400 mb-4">
          Secure account deletion workflow. This action is irreversible and requires multi-step confirmation.
        </p>
        
        {!showDeleteConfirm ? (
          <button 
            onClick={() => setShowDeleteConfirm(true)}
            className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/30 rounded-lg text-sm font-bold transition-colors"
          >
            Initiate Account Deletion
          </button>
        ) : (
          <div className="p-4 bg-slate-950 border border-red-500/50 rounded-lg max-w-md">
            <p className="text-sm text-white font-bold mb-2">Are you absolutely sure?</p>
            <p className="text-xs text-slate-400 mb-4">Please type <strong className="text-red-400 select-none">DELETE-MY-ORG</strong> to confirm.</p>
            <input 
              type="text" 
              className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-sm text-white focus:outline-none focus:border-red-500 mb-4"
            />
            <div className="flex gap-3">
              <button className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-sm font-bold transition-colors">
                Confirm Deletion
              </button>
              <button 
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-bold transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
