import React from 'react';
import { FileText, BookOpen } from 'lucide-react';
import { InterventionLog } from '../types';

interface StaffDocsViewProps {
  logs: InterventionLog[];
}

export const StaffDocsView: React.FC<StaffDocsViewProps> = ({ logs }) => {
  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <FileText className="w-6 h-6 text-brand-cyan" />
          Staff Docs
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Staff-facing documentation and accountability.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col h-[700px]">
        <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-brand-cyan" />
          Staff Action Stream
        </h3>
        <p className="text-sm text-slate-400 mb-6">Audit trail and BHT reliability metrics.</p>
        
        <div className="flex-1 overflow-y-auto pr-2 space-y-4 custom-scrollbar">
          {logs.map(log => (
            <div key={log.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-300">
                    {log.authorName.charAt(0)}
                  </div>
                  <div>
                    <span className="font-bold text-slate-200 text-sm block">{log.authorName}</span>
                    <span className="text-xs text-slate-500">{log.authorRole}</span>
                  </div>
                </div>
                <span className="text-xs text-slate-500">
                  {new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </span>
              </div>
              <p className="text-sm text-slate-300 mt-3">{log.action}</p>
              {log.lessonLearned && (
                <div className="mt-3 p-3 rounded-lg bg-brand-magenta/10 border border-brand-magenta/20">
                  <span className="text-[10px] font-bold text-brand-magenta uppercase tracking-wider block mb-1">System Note</span>
                  <p className="text-sm text-brand-magenta/90 italic">{log.lessonLearned}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
