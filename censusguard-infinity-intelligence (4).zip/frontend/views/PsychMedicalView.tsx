import React from 'react';
import { Stethoscope, Clock, ClipboardList, Pill, AlertTriangle, CheckCircle2 } from 'lucide-react';

export const PsychMedicalView: React.FC = () => {
  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Stethoscope className="w-6 h-6 text-brand-cyan" />
          Psychiatric & Medical
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Provider-level interventions and clinical-medical accountability.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Provider Metrics */}
        <div className="lg:col-span-3 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Pending Consults</div>
            <div className="text-3xl font-bold text-orange-500">8</div>
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Completed (7d)</div>
            <div className="text-3xl font-bold text-white">24</div>
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Med Adjustments</div>
            <div className="text-3xl font-bold text-brand-cyan">12</div>
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Avg Response Time</div>
            <div className="text-3xl font-bold text-white flex items-center gap-2">
              4.2h <Clock className="w-5 h-5 text-slate-500" />
            </div>
          </div>
        </div>

        {/* Left Column: Tasks & Consults */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-brand-magenta" />
              Provider Follow-up Tasks & Pending Consults
            </h3>
            <div className="space-y-4">
              {[
                { name: 'David L.', type: 'MAT / MOUD Consult', desc: 'High Risk • Psych Comorbidity Flagged', urgency: 'High' },
                { name: 'Sarah J.', type: 'Medication Change Review', desc: 'Refusing current protocol. Evaluate alternatives.', urgency: 'High' },
                { name: 'Chloe M.', type: 'Withdrawal Management', desc: 'COWS score elevated. Review PRN efficacy.', urgency: 'Medium' },
                { name: 'Marcus T.', type: 'Pain Management Concern', desc: 'Reporting 8/10 pain. Risk of AMA if unmanaged.', urgency: 'Medium' },
              ].map((task, idx) => (
                <div key={idx} className="flex items-center justify-between p-4 bg-slate-950 border border-slate-800 rounded-lg hover:border-brand-cyan/50 cursor-pointer transition-colors">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-slate-200">{task.name}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-bold tracking-wider ${
                        task.urgency === 'High' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'
                      }`}>{task.urgency}</span>
                    </div>
                    <div className="text-sm font-medium text-brand-cyan mb-1">{task.type}</div>
                    <div className="text-xs text-slate-400">{task.desc}</div>
                  </div>
                  <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-sm font-bold transition-colors">
                    Open Chart
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              Recently Completed Consults
            </h3>
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                <div>
                  <div className="text-sm font-bold text-slate-300">Elena R. <span className="text-xs font-normal text-slate-500 ml-2">Psychiatric Evaluation</span></div>
                  <div className="text-xs text-slate-500 mt-1">Completed by Dr. Smith • 2 hours ago</div>
                </div>
                <span className="text-xs text-green-500 font-medium">Signed</span>
              </div>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex justify-between items-center">
                <div>
                  <div className="text-sm font-bold text-slate-300">James W. <span className="text-xs font-normal text-slate-500 ml-2">MAT Follow-up</span></div>
                  <div className="text-xs text-slate-500 mt-1">Completed by Dr. Adams • 5 hours ago</div>
                </div>
                <span className="text-xs text-green-500 font-medium">Signed</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Active Clinical Concerns */}
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              Active Clinical Concerns
            </h3>
            
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-slate-950 border border-slate-800">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Pill className="w-3.5 h-3.5" /> Withdrawal Management
                </div>
                <div className="text-sm text-slate-300">
                  <span className="font-bold text-white">3 patients</span> currently have elevated COWS/CIWA scores requiring monitoring.
                </div>
              </div>

              <div className="p-4 rounded-lg bg-slate-950 border border-slate-800">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Activity className="w-3.5 h-3.5" /> Pain Management
                </div>
                <div className="text-sm text-slate-300">
                  <span className="font-bold text-white">2 patients</span> reporting pain scores > 7/10. High correlation with AMA risk.
                </div>
              </div>

              <div className="p-4 rounded-lg bg-slate-950 border border-slate-800">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <Stethoscope className="w-3.5 h-3.5" /> Psych Comorbidity Flags
                </div>
                <div className="text-sm text-slate-300">
                  <span className="font-bold text-white">14% of census</span> flagged for severe co-occurring psychiatric symptoms.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
