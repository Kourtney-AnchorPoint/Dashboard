import React from 'react';
import { TrendingUp, Activity, ShieldCheck, DollarSign } from 'lucide-react';

export const ClinicalOutcomesView: React.FC = () => {
  return (
    <div className="animate-fade-in pb-20 md:pb-0">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-brand-cyan" />
          Clinical Outcomes
        </h2>
        <p className="text-sm text-slate-400 mt-1">
          Measuring intervention efficacy and system learning.
        </p>
      </div>

      {/* Executive Summary Section */}
      <div className="mb-8">
        <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Executive Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex items-center gap-6">
            <div className="p-4 bg-brand-cyan/10 rounded-full">
              <ShieldCheck className="w-8 h-8 text-brand-cyan" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Audit Coverage</div>
              <div className="text-3xl font-bold text-white">100%</div>
              <div className="text-xs text-slate-400 mt-1">All critical alerts documented</div>
            </div>
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex items-center gap-6">
            <div className="p-4 bg-brand-magenta/10 rounded-full">
              <DollarSign className="w-8 h-8 text-brand-magenta" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Est. Savings (POC Logic)</div>
              <div className="text-3xl font-bold text-white">$134,000</div>
              <div className="text-xs text-slate-400 mt-1">Revenue protected from AMA</div>
            </div>
          </div>
        </div>
      </div>

      <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Clinical Metrics</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Intervening Patients</div>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-bold text-white">24</span>
            <span className="text-sm text-green-500 mb-1 flex items-center"><TrendingUp className="w-4 h-4 mr-1"/> 12%</span>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Avg Score Reduction</div>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-bold text-brand-cyan">-14 pts</span>
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Loop Closure Rate</div>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-bold text-white">88%</span>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
          <Activity className="w-5 h-5 text-brand-magenta" />
          Recent Intervention Outcomes
        </h3>
        <div className="space-y-3">
          {[
            { name: 'David L.', action: 'Patient engaged well, agreed to stay.', pre: 92, post: 75, status: 'Success' },
            { name: 'Sarah J.', action: 'Meds adjusted by MD, warning signs.', pre: 83, post: 83, status: 'Partial' },
            { name: 'Marcus T.', action: 'Conflict resolved after room change.', pre: 65, post: 45, status: 'Success' },
          ].map((item, idx) => (
            <div key={idx} className="flex items-center justify-between p-4 bg-slate-950 border border-slate-800 rounded-lg">
              <div>
                <div className="font-bold text-slate-200">{item.name}</div>
                <div className="text-sm text-slate-400 mt-1">{item.action}</div>
              </div>
              <div className="flex items-center gap-8">
                <div className="text-center">
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Score Change</div>
                  <div className="flex items-center gap-2 text-lg font-bold">
                    <span className="text-brand-magenta">{item.pre}</span>
                    <span className="text-slate-600">→</span>
                    <span className="text-brand-cyan">{item.post}</span>
                  </div>
                </div>
                <div className={`px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider border ${
                  item.status === 'Success' ? 'bg-brand-cyan/10 text-brand-cyan border-brand-cyan/20' : 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
                }`}>
                  {item.status}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
