export interface Observation {
  timestamp: string;
  location: string;
  activity: string;
  staffName: string;
  staffCredentials: string;
  isSuspicious?: boolean;
  suspiciousReason?: string;
}

export type LoopStage = 'detect' | 'alert' | 'intervene' | 'document' | 'prove' | 'learn';

export interface Patient {
  id: string;
  name: string;
  room: string;
  unit: string;
  riskScore: 'Low' | 'Moderate' | 'High' | 'Critical';
  riskScoreValue: number;
  velocity: number;
  flags: string[];
  counselor: string;
  substance: string;
  daysInTreatment: number;
  predictedDischarge: number; // days from now
  status: string;
  loopStage: LoopStage;
  lastObservation?: Observation;
  peerRisk?: string[]; // Names of high-risk peers currently in proximity
  vitals: {
    hr: number;
    bp: string;
    lastUpdated: string;
  };
}

export interface InterventionLog {
  id: string;
  patientId: string;
  timestamp: string;
  action: string;
  outcome: 'positive' | 'neutral' | 'negative';
  lessonLearned?: string;
  authorRole: string;
  authorName: string;
  authorCredentials?: string;
}

export interface NursingNote {
  id: string;
  patientId: string;
  timestamp: string;
  note: string;
  authorRole: string;
  authorCredentials?: string;
  isHighSignal: boolean;
}

export interface NarrativeNote {
  id: string;
  type: 'Conflict' | 'Clinical Note' | 'Positive' | 'Group Milestone' | 'Cohesion Drop' | 'Warning' | 'Alert';
  unit: string;
  authorName: string;
  authorCredentials?: string;
  timestamp: string;
  text: string;
  cohesionScore?: number;
}

export interface AIInsight {
  who: string;
  what: string;
  when: string;
  outcome: string;
}

export interface Alert {
  id: string;
  type: 'critical' | 'warning' | 'info';
  message: string;
  patientId?: string;
  patientName?: string;
  timestamp: string;
  recommendedAction?: string;
  assignedTo?: string;
}

export interface Room {
  id: string;
  number: string;
  capacity: number;
  patients: string[]; // Patient IDs
  unit: string;
}

export interface AnalyticsData {
  riskTier: string;
  successRate: number;
  totalInterventions: number;
}

export interface MOUDData {
  setting: string;
  moudRate: number;
  nonMoudRate: number;
}
