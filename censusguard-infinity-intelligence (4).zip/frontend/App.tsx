import React, { useState } from 'react';
import { Patient, LoopStage } from './types';
import { mockPatients, mockRooms, mockAlerts, mockMOUDData, mockInterventionLogs, mockNarrativeNotes } from './mockData';
import { PatientDrawer } from './components/PatientDrawer';
import { Navigation, TabType } from './components/Navigation';
import { ClosedLoopMap } from './components/ClosedLoopMap';
import { MonitorView } from './views/MonitorView';
import { FloorPlanView } from './views/FloorPlanView';
import { CommandCenterView } from './views/CommandCenterView';
import { ClinicalOutcomesView } from './views/ClinicalOutcomesView';
import { MOUDAnalysisView } from './views/MOUDAnalysisView';
import { StaffDocsView } from './views/StaffDocsView';
import { PsychMedicalView } from './views/PsychMedicalView';
import { GroupFlowView } from './views/GroupFlowView';
import { NarrativeView } from './views/NarrativeView';
import { LearnView } from './views/LearnView';
import { SettingsView } from './views/SettingsView';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('monitor');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [loopFilter, setLoopFilter] = useState<LoopStage | null>(null);

  const handleLoopStageClick = (stage: LoopStage) => {
    // Toggle filter off if clicking the already active stage
    if (loopFilter === stage) {
      setLoopFilter(null);
    } else {
      setLoopFilter(stage);
      setActiveTab('monitor'); // Auto-navigate to monitor to see the filtered list
    }
  };

  const renderView = () => {
    switch (activeTab) {
      case 'monitor':
        return <MonitorView patients={mockPatients} onSelectPatient={setSelectedPatient} loopFilter={loopFilter} />;
      case 'floorplan':
        return <FloorPlanView rooms={mockRooms} patients={mockPatients} onSelectPatient={setSelectedPatient} />;
      case 'groupflow':
        return <GroupFlowView patients={mockPatients} onSelectPatient={setSelectedPatient} />;
      case 'narrative':
        return <NarrativeView notes={mockNarrativeNotes} />;
      case 'command':
        return <CommandCenterView alerts={mockAlerts} patients={mockPatients} />;
      case 'outcomes':
        return <ClinicalOutcomesView />;
      case 'moud':
        return <MOUDAnalysisView data={mockMOUDData} />;
      case 'learn':
        return <LearnView />;
      case 'staff':
        return <StaffDocsView logs={mockInterventionLogs} />;
      case 'psych':
        return <PsychMedicalView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <MonitorView patients={mockPatients} onSelectPatient={setSelectedPatient} loopFilter={loopFilter} />;
    }
  };

  return (
    <div className="min-h-screen bg-brand-dark flex font-sans text-slate-300">
      
      {/* Navigation Sidebar */}
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        
        {/* Top Stats Bar (Desktop) */}
        <header className="hidden md:flex bg-brand-panel border-b border-slate-800 px-8 py-4 items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-8">
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Open Alerts</span>
              <span className="text-xl font-bold text-brand-magenta">7</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Critical Patients</span>
              <span className="text-xl font-bold text-red-500">2</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">High-Risk Patients</span>
              <span className="text-xl font-bold text-orange-500">5</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Avg Risk Score</span>
              <span className="text-xl font-bold text-brand-cyan">58</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setActiveTab('command')}
              className="px-4 py-1.5 bg-brand-magenta/10 text-brand-magenta border border-brand-magenta/30 rounded text-xs font-bold uppercase tracking-wider hover:bg-brand-magenta/20 transition-colors"
            >
              Clinical Command Center
            </button>
            <button className="px-4 py-1.5 bg-brand-cyan text-brand-dark hover:bg-brand-cyan/90 rounded text-xs font-bold uppercase tracking-wider transition-colors">
              Get Access
            </button>
          </div>
        </header>

        {/* Closed-Loop Map */}
        <ClosedLoopMap activeStageFilter={loopFilter} onStageClick={handleLoopStageClick} />

        {/* Mobile Header */}
        <header className="md:hidden bg-brand-panel border-b border-slate-800 px-4 py-3 flex items-center justify-between sticky top-0 z-30">
          <h1 className="text-lg font-bold text-white tracking-tight">CENSUSGUARD</h1>
          <div className="w-2 h-2 rounded-full bg-brand-cyan animate-pulse"></div>
        </header>

        {/* Scrollable View Container */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar">
          <div className="max-w-7xl mx-auto">
            {renderView()}
          </div>
        </div>
      </main>

      {/* Overlay & Drawer */}
      {selectedPatient && (
        <>
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity"
            onClick={() => setSelectedPatient(null)}
          />
          <PatientDrawer 
            patient={selectedPatient} 
            onClose={() => setSelectedPatient(null)} 
          />
        </>
      )}
    </div>
  );
};

export default App;
