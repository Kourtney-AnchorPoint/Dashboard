import { Patient, InterventionLog, NursingNote, NarrativeNote, Alert, Room, AnalyticsData, MOUDData } from './types';

export const mockPatients: Patient[] = [
  {
    id: 'p-101',
    name: 'David L.',
    room: '104A',
    unit: 'Detox',
    riskScore: 'Critical',
    riskScoreValue: 92,
    velocity: 1.8,
    flags: ['Calm-Before-Storm'],
    counselor: 'Jane Roe, LCSW',
    substance: 'Methamphetamine',
    daysInTreatment: 2,
    predictedDischarge: 5,
    status: '1 Active',
    loopStage: 'intervene',
    peerRisk: ['Chloe M.'],
    lastObservation: {
      timestamp: '5 mins ago',
      location: 'Day Room',
      activity: 'Pacing, speaking loudly to peers.',
      staffName: 'Mark Johnson',
      staffCredentials: 'BHT',
      isSuspicious: false
    },
    vitals: { hr: 112, bp: '145/90', lastUpdated: '10 mins ago' }
  },
  {
    id: 'p-102',
    name: 'Sarah J.',
    room: '105B',
    unit: 'Detox',
    riskScore: 'High',
    riskScoreValue: 83,
    velocity: 0.5,
    flags: ['Medication Refusal'],
    counselor: 'Jane Roe, LCSW',
    substance: 'Opioids',
    daysInTreatment: 5,
    predictedDischarge: 7,
    status: '1 Active',
    loopStage: 'alert',
    lastObservation: {
      timestamp: '15 mins ago',
      location: 'Patient Room',
      activity: 'Resting in bed, refused group.',
      staffName: 'Sarah Connor',
      staffCredentials: 'RN',
      isSuspicious: false
    },
    vitals: { hr: 82, bp: '120/80', lastUpdated: '1 hour ago' }
  },
  {
    id: 'p-103',
    name: 'Chloe M.',
    room: '402A',
    unit: 'Residential',
    riskScore: 'High',
    riskScoreValue: 78,
    velocity: 2.1,
    flags: ['Agitation Spikes'],
    counselor: 'John Doe, CADC-II',
    substance: 'Cannabis',
    daysInTreatment: 14,
    predictedDischarge: 28,
    status: '1 Active',
    loopStage: 'document',
    peerRisk: ['David L.'],
    lastObservation: {
      timestamp: '2 mins ago',
      location: 'Day Room',
      activity: 'Sitting with David L., whispering.',
      staffName: 'Mark Johnson',
      staffCredentials: 'BHT',
      isSuspicious: false
    },
    vitals: { hr: 125, bp: '155/95', lastUpdated: '2 mins ago' }
  },
  {
    id: 'p-104',
    name: 'Elena R.',
    room: '204B',
    unit: 'PHP',
    riskScore: 'Moderate',
    riskScoreValue: 65,
    velocity: -0.2,
    flags: [],
    counselor: 'John Doe, CADC-II',
    substance: 'Alcohol',
    daysInTreatment: 22,
    predictedDischarge: 2,
    status: '1 Active',
    loopStage: 'detect',
    lastObservation: {
      timestamp: 'Just now',
      location: 'Living Room',
      activity: 'Watching TV.',
      staffName: 'Alex Smith',
      staffCredentials: 'BHT',
      isSuspicious: true,
      suspiciousReason: 'Low-signal entry detected. Exact phrase "Watching TV." used 4 times in the last 2 hours for this patient.'
    },
    vitals: { hr: 72, bp: '118/75', lastUpdated: '4 hours ago' }
  },
  {
    id: 'p-105',
    name: 'James W.',
    room: '305A',
    unit: 'IOP',
    riskScore: 'Low',
    riskScoreValue: 22,
    velocity: -0.5,
    flags: [],
    counselor: 'Dr. Smith, MD',
    substance: 'Alcohol',
    daysInTreatment: 45,
    predictedDischarge: 0,
    status: '1 Active',
    loopStage: 'prove',
    lastObservation: {
      timestamp: '1 hour ago',
      location: 'Group Room B',
      activity: 'Participating in relapse prevention group.',
      staffName: 'Lisa Ray',
      staffCredentials: 'LMFT',
      isSuspicious: false
    },
    vitals: { hr: 68, bp: '115/70', lastUpdated: '1 day ago' }
  },
  {
    id: 'p-106',
    name: 'Marcus T.',
    room: '402B',
    unit: 'Residential',
    riskScore: 'Moderate',
    riskScoreValue: 45,
    velocity: 0.1,
    flags: [],
    counselor: 'Jane Roe, LCSW',
    substance: 'Opioids',
    daysInTreatment: 18,
    predictedDischarge: 12,
    status: '1 Active',
    loopStage: 'learn',
    lastObservation: {
      timestamp: '30 mins ago',
      location: 'Courtyard',
      activity: 'Reading a book alone.',
      staffName: 'Mark Johnson',
      staffCredentials: 'BHT',
      isSuspicious: false
    },
    vitals: { hr: 75, bp: '122/80', lastUpdated: '5 hours ago' }
  }
];

export const mockInterventionLogs: InterventionLog[] = [
  {
    id: 'log-1',
    patientId: 'p-101',
    timestamp: '2023-10-26T08:30:00Z',
    action: 'Performed Assessment Check for patient Marcus T.',
    outcome: 'positive',
    authorRole: 'RN',
    authorName: 'Nurse Ratched',
    authorCredentials: 'BSN, RN'
  },
  {
    id: 'log-2',
    patientId: 'p-103',
    timestamp: '2023-10-26T09:15:00Z',
    action: 'Performed Milieu Check for patient Multiple. Observing BHT dynamics. Staff intervention required but not documented.',
    outcome: 'negative',
    lessonLearned: 'Staff Action Loop stalled. Intervention required but not documented.',
    authorRole: 'Supervisor',
    authorName: 'John Doe',
    authorCredentials: 'CADC-II'
  }
];

export const mockNursingNotes: NursingNote[] = [
  {
    id: 'note-1',
    patientId: 'p-101',
    timestamp: '2023-10-26T09:00:00Z',
    note: 'Patient pacing hallway. Refused breakfast. Stated "I need to get out of here before I lose it." Heart rate elevated.',
    authorRole: 'RN',
    authorCredentials: 'BSN, RN',
    isHighSignal: true
  }
];

export const mockNarrativeNotes: NarrativeNote[] = [
  {
    id: 'narr-1',
    type: 'Conflict',
    unit: 'Residential',
    authorName: 'John Doe',
    authorCredentials: 'CADC-II',
    timestamp: '2023-10-26T14:00:00Z',
    text: 'James T. and David L. had a conflict at lunch — raised voices over seat assignment. Staff intervened immediately. Both patients separated for the remainder of the meal.',
    cohesionScore: 65
  }
];

export const mockAlerts: Alert[] = [
  {
    id: 'alert-1',
    type: 'critical',
    message: 'Calm-Before-Storm detected: Sudden 100% compliance after 3 days of refusal.',
    patientId: 'p-101',
    patientName: 'David L.',
    timestamp: '10 mins ago',
    recommendedAction: 'MI 1:1 Session',
    assignedTo: 'Jane Roe, LCSW'
  }
];

export const mockRooms: Room[] = [
  { id: 'r-104', number: '104', capacity: 2, patients: ['p-101'], unit: 'Detox' },
  { id: 'r-105', number: '105', capacity: 2, patients: ['p-102'], unit: 'Detox' },
  { id: 'r-402', number: '402', capacity: 2, patients: ['p-103', 'p-106'], unit: 'Residential' },
  { id: 'r-204', number: '204', capacity: 2, patients: ['p-104'], unit: 'PHP' },
  { id: 'r-305', number: '305', capacity: 2, patients: ['p-105'], unit: 'IOP' },
];

export const mockAnalytics: AnalyticsData[] = [
  { riskTier: 'Low', successRate: 92, totalInterventions: 150 },
  { riskTier: 'Moderate', successRate: 78, totalInterventions: 320 },
  { riskTier: 'High', successRate: 54, totalInterventions: 410 },
  { riskTier: 'Critical', successRate: 31, totalInterventions: 180 },
];

export const mockMOUDData: MOUDData[] = [
  { setting: 'Inpatient Detox', moudRate: 19.4, nonMoudRate: 17.6 },
  { setting: 'Short-term Residential', moudRate: 31.6, nonMoudRate: 27.7 },
  { setting: 'Long-term Residential', moudRate: 43.7, nonMoudRate: 35.7 },
  { setting: 'PHP / IOP', moudRate: 62.2, nonMoudRate: 51.6 },
];
