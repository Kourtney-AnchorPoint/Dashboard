import { GoogleGenAI, Type } from '@google/genai';
import { Patient, InterventionLog, NursingNote, AIInsight } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY, vertexai: true });

const SYSTEM_PROMPT = `You are an expert Clinical Intelligence partner for CensusGuard Infinity Intelligence. Your purpose is to support clinical staff, not replace them.
Goal: Analyze the provided patient history (InterventionLogs, NursingNotes, and Vitals) and return structured insights for the 'Staff Action Loop'.
Guidelines:
MI-Informed Language: Every output must use Motivational Interviewing terminology (e.g., 'explore ambivalence,' 'validate reality,' 'evoke change talk'). Never use auditing or punitive language.
Loop Structure: Provide insights specifically in this format:
WHO: Identify the most relevant staff role (BHT, Nurse, Counselor).
WHAT: Suggest a specific, low-pressure conversational opener.
WHEN: Identify the 'Cliff Window' or optimal engagement time based on vitals/velocity.
OUTCOME: Define what a 'success' looks like for this specific interaction (e.g., 'patient acknowledges desire to stay').
Risk Focus: If velocity is >1.5 or the 'Calm-Before-Storm' flag is present, prioritize engagement over compliance.
Learning Integration: Reference the 'What Worked' patterns from the global Learning Library for this specific substance/risk-tier combination.`;

export const generateClinicalInsight = async (
  patient: Patient,
  logs: InterventionLog[],
  notes: NursingNote[]
): Promise<AIInsight> => {
  try {
    const prompt = `
      Analyze the following patient data and generate a Staff Action Loop insight.
      
      Patient: ${patient.name}
      Risk Score: ${patient.riskScore}
      Velocity: ${patient.velocity}
      Flags: ${patient.flags.join(', ')}
      Vitals: HR ${patient.vitals.hr}, BP ${patient.vitals.bp}
      
      Recent Nursing Notes:
      ${notes.map(n => `[${n.timestamp}] ${n.authorRole}: ${n.note}`).join('\n')}
      
      Recent Intervention Logs (Learning Library):
      ${logs.map(l => `[${l.outcome.toUpperCase()}] Action: ${l.action} | Lesson: ${l.lessonLearned || 'N/A'}`).join('\n')}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            who: {
              type: Type.STRING,
              description: 'The most relevant staff role (e.g., BHT, Nurse, Counselor).',
            },
            what: {
              type: Type.STRING,
              description: 'A specific, low-pressure conversational opener using MI language.',
            },
            when: {
              type: Type.STRING,
              description: 'The optimal engagement time or Cliff Window based on vitals/velocity.',
            },
            outcome: {
              type: Type.STRING,
              description: 'What success looks like for this specific interaction.',
            },
          },
          required: ['who', 'what', 'when', 'outcome'],
        },
      },
    });

    if (!response.text) {
      throw new Error('No response received from the model.');
    }

    return JSON.parse(response.text) as AIInsight;
  } catch (error) {
    console.error('Error generating clinical insight:', error);
    throw new Error('Failed to generate Infinity Insight. Please rely on standard clinical protocols.');
  }
};
