import { Patient } from '../types';

/**
 * CENSUSGUARD POC - VERTEX AI BRIDGE SIMULATION
 * 
 * As per the architecture spec:
 * "The browser frontend must not call Vertex AI directly with Google credentials.
 * Use a backend bridge instead: React dashboard calls /api/score -> Cloud Run backend -> Vertex AI."
 */

export interface ScorePayload {
  patientId: string;
  features: {
    daysInTreatment: number;
    currentVelocity: number;
    activeFlags: string[];
    substance: string;
    painScore: number;
    moudStatus: string;
    psychComorbidity: boolean;
    recentSuspiciousLogs: number;
    peerRiskCount: number;
  };
}

export interface ScoreResponse {
  predictedScore: number;
  predictedTier: 'Low' | 'Moderate' | 'High' | 'Critical';
  confidence: number;
  topContributingFactors: string[];
  recommendedLoopStage: string;
}

// Simulated frontend call to the Cloud Run backend
export const fetchPatientScore = async (payload: ScorePayload): Promise<ScoreResponse> => {
  console.log('Calling backend bridge: POST /api/score', payload);
  
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 800));

  // In production, this would be:
  // const response = await fetch('/api/score', { method: 'POST', body: JSON.stringify(payload) });
  // return response.json();

  // Simulated response based on POC logic
  return {
    predictedScore: Math.min(100, Math.max(0, 50 + (payload.features.currentVelocity * 10) + (payload.features.peerRiskCount * 5))),
    predictedTier: payload.features.currentVelocity > 1.5 ? 'Critical' : 'High',
    confidence: 0.89,
    topContributingFactors: [
      'Velocity spike in last 4 hours',
      'Proximity to high-risk peer',
      'Low-signal BHT documentation detected'
    ],
    recommendedLoopStage: 'alert'
  };
};
